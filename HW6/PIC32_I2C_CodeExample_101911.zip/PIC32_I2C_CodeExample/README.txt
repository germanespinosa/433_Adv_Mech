	Readme File for Code Example:
--------------------------------------------------

PIC32_I2C

--------------------------------------------------
Code Example Description:
--------------------------------------------------
This demo code excersize the i2c channel 1 by interfacing to 24LC256 serial eeprom.  The code writes to a location and then verify the contents of the eeprom.  I2C Channel 1 is hooked up to 24LC256.  Address lines of the eeprom are all tied to Vss.

--------------------------------------------------
Suggested Development Resources:
--------------------------------------------------
Explorer 16 demo board with 

Processors:	PIC32MX###F512L
		       360
		       460
		       795
            PIC32MX220F032D (not supported on Explorer 16)
		PIC32MX250F128D (not supported on Explorer 16)

Complier:	MPLAB C32 v1 or higher

IDE:
		MPLAB IDE v8 or higher
            MPLAB X IDE

--------------------------------------------------
Further Documentation:
--------------------------------------------------
For more information on this topic see Family Reference Manual (FRM)

FRM PDF can be found on Microchip website by searching for: 
"PIC32 Family Reference Manual, Sect. 24 Inter-Integrated Circuit"